1. u have to have idm installed first
2. turn off your internet (i mean it will still work with internet but without internet would be much smoother)
3. unzip the file and inside u will find idm.exe
4. copy it
5. go to the location of where u installed idm in your computer and paste it there
6. click ok to replace
7. and after u are done with the replacing u are done with the first stage
8. now open idm by double clicking on it
9. and go the registration
10. put firstname, lastname and email and for the serial number you can put whatever u want but make sure they are in groups of 5 and they are separated by a - and they have to be 4 groups in total



example serial numbers: 12345-12345-12345-12345 or 11111-22222-33333-44444 



it has to be this like format i just showed u on the example



10\. after u have put all of them u can click "ok" and it will load for some time and it will close on it's own or it will show u something in a pop up u just click ok and if it's stuck u can close it and when u go back and open it again check the registration again u will see that it has been registered successfully 

